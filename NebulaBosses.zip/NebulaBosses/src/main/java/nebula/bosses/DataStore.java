package nebula.bosses;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

/** Cooldowns persistentes (data.yml). Claves: "player:<uuid>:<boss>" y "arena:<boss>". */
public final class DataStore {
    private final NebulaBosses plugin;
    private final File file;
    private final Map<String, Long> expires = new HashMap<>();

    public DataStore(NebulaBosses plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "data.yml");
        load();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection s = y.getConfigurationSection("cooldowns");
        if (s == null) return;
        long now = System.currentTimeMillis();
        for (String k : s.getKeys(false)) {
            long t = s.getLong(k);
            if (t > now) expires.put(k, t);
        }
    }

    private void save() {
        YamlConfiguration y = new YamlConfiguration();
        for (Map.Entry<String, Long> e : expires.entrySet()) y.set("cooldowns." + e.getKey(), e.getValue());
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException ex) {
            plugin.getLogger().log(Level.WARNING, "No se pudo guardar data.yml", ex);
        }
    }

    /** Segundos restantes (0 si no hay cooldown). */
    public long remaining(String key) {
        Long t = expires.get(key);
        if (t == null) return 0;
        long left = (t - System.currentTimeMillis() + 999) / 1000;
        if (left <= 0) {
            expires.remove(key);
            return 0;
        }
        return left;
    }

    public void setCooldown(String key, long seconds) {
        if (seconds <= 0) return;
        expires.put(key, System.currentTimeMillis() + seconds * 1000L);
        save();
    }

    /** Reinicia cooldowns de un jugador (bossId null = todos los bosses). */
    public void resetPlayer(UUID id, String bossId) {
        String prefix = "player:" + id + ":";
        Iterator<String> it = expires.keySet().iterator();
        while (it.hasNext()) {
            String k = it.next();
            if (k.startsWith(prefix) && (bossId == null || k.equals(prefix + bossId))) it.remove();
        }
        save();
    }
}

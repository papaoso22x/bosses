package nebula.bosses;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public final class BossCommand implements CommandExecutor, TabCompleter {
    private static final List<String> SUBS = List.of("list", "join", "leave", "start", "lock", "invite", "accept", "info", "help");
    private static final List<String> ADMIN = List.of("reload", "create", "setlobby", "setarena", "setboss", "setexit",
            "event", "stop", "resetcooldown");

    private final NebulaBosses plugin;

    public BossCommand(NebulaBosses plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        Lang l = plugin.lang();
        if (args.length == 0) {
            help(sender);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (sub.equals("admin")) {
            admin(sender, args);
            return true;
        }
        if (sub.equals("list")) {
            list(sender);
            return true;
        }
        if (!(sender instanceof Player p)) {
            l.send(sender, "player-only");
            return true;
        }
        SessionManager sm = plugin.sessions();
        Session s = sm.sessionOf(p.getUniqueId());
        switch (sub) {
            case "join" -> {
                if (args.length < 2) {
                    l.send(p, "usage-join");
                    return true;
                }
                BossDefinition d = plugin.boss(args[1]);
                if (d == null) l.send(p, "unknown-boss");
                else sm.join(p, d);
            }
            case "leave" -> {
                if (s == null) l.send(p, "not-in-session");
                else s.leave(p, true);
            }
            case "start" -> {
                if (s == null) {
                    l.send(p, "not-in-session");
                } else if (!p.getUniqueId().equals(s.leader)) {
                    l.send(p, "not-leader");
                } else if (s.kind != Session.Kind.MANUAL
                        || (s.state != Session.State.WAITING && s.state != Session.State.COUNTDOWN)) {
                    l.send(p, "cannot-start");
                } else if (s.players.size() < s.def.min) {
                    l.send(p, "not-enough-players", "min", s.def.min);
                } else {
                    s.forceCountdown(5);
                }
            }
            case "lock" -> {
                if (s == null) {
                    l.send(p, "not-in-session");
                } else if (!p.getUniqueId().equals(s.leader)) {
                    l.send(p, "not-leader");
                } else if (s.kind != Session.Kind.MANUAL
                        || (s.state != Session.State.WAITING && s.state != Session.State.COUNTDOWN)) {
                    l.send(p, "cannot-start");
                } else {
                    s.locked = !s.locked;
                    l.send(p, s.locked ? "lock-on" : "lock-off");
                }
            }
            case "invite" -> {
                if (s == null) {
                    l.send(p, "not-in-session");
                } else if (!p.getUniqueId().equals(s.leader)) {
                    l.send(p, "not-leader");
                } else if (args.length < 2) {
                    l.send(p, "invite-bad-player");
                } else {
                    Player t = Bukkit.getPlayerExact(args[1]);
                    if (t == null || t.equals(p)) l.send(p, "invite-bad-player");
                    else if (s.kind != Session.Kind.MANUAL
                            || (s.state != Session.State.WAITING && s.state != Session.State.COUNTDOWN)) l.send(p, "cannot-start");
                    else sm.invite(s, p, t);
                }
            }
            case "accept" -> sm.accept(p);
            case "info" -> {
                if (s == null) {
                    l.send(p, "not-in-session");
                } else {
                    l.send(p, "info-line", "boss", s.def.display, "state", s.state.name(),
                            "n", s.players.size(), "max", s.maxPlayers());
                }
            }
            default -> help(p);
        }
        return true;
    }

    private void help(CommandSender to) {
        for (String line : plugin.lang().list("help")) to.sendMessage(Lang.c(line));
    }

    private void list(CommandSender to) {
        Lang l = plugin.lang();
        to.sendMessage(l.comp("list-header"));
        for (BossDefinition d : plugin.bosses()) {
            int n = plugin.sessions().countFor(d);
            String state = n == 0 ? "libre" : (d.type == BossDefinition.Type.FIXED ? "en uso" : n + " activa(s)");
            to.sendMessage(l.comp("list-line", "id", d.id, "display", d.display, "type", d.type.name(),
                    "min", d.min, "max", d.max, "state", state));
            if (d.scheduled && !d.times.isEmpty()) {
                to.sendMessage(l.comp("list-next", "next", plugin.schedule().describeNext(d)));
            }
            if (to instanceof Player p) {
                long cd = plugin.data().remaining("player:" + p.getUniqueId() + ":" + d.id);
                if (cd > 0) to.sendMessage(l.comp("list-cooldown", "time", Lang.time(cd)));
            }
        }
    }

    // ------------------------------------------------------------------ admin

    private void admin(CommandSender sender, String[] args) {
        Lang l = plugin.lang();
        if (!sender.hasPermission("nebulabosses.admin")) {
            l.send(sender, "no-permission");
            return;
        }
        if (args.length < 2) {
            l.send(sender, "admin-usage");
            return;
        }
        String sub = args[1].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "reload" -> {
                plugin.reloadAll();
                l.send(sender, "admin-reloaded");
            }
            case "create" -> {
                if (args.length < 4) {
                    l.send(sender, "admin-usage");
                    return;
                }
                String id = args[2].toLowerCase(Locale.ROOT);
                if (!NebulaBosses.validId(id)) {
                    l.send(sender, "admin-invalid-id");
                    return;
                }
                if (plugin.boss(id) != null) {
                    l.send(sender, "admin-exists");
                    return;
                }
                BossDefinition.Type type;
                try {
                    type = BossDefinition.Type.valueOf(args[3].toUpperCase(Locale.ROOT));
                } catch (IllegalArgumentException e) {
                    l.send(sender, "admin-invalid-type");
                    return;
                }
                plugin.createBoss(id, type);
                l.send(sender, "admin-created", "id", id);
            }
            case "setlobby", "setarena", "setboss", "setexit" -> {
                if (!(sender instanceof Player p)) {
                    l.send(sender, "player-only");
                    return;
                }
                if (args.length < 3) {
                    l.send(sender, "admin-usage");
                    return;
                }
                BossDefinition d = plugin.boss(args[2]);
                if (d == null) {
                    l.send(sender, "unknown-boss");
                    return;
                }
                String key = switch (sub) {
                    case "setlobby" -> "lobby";
                    case "setarena" -> "arena-spawn";
                    case "setboss" -> "boss-spawn";
                    default -> "exit";
                };
                plugin.setLocation(d.id, key, p.getLocation());
                l.send(sender, "admin-set", "key", key, "id", d.id);
            }
            case "event" -> {
                BossDefinition d = args.length < 3 ? null : plugin.boss(args[2]);
                if (d == null) {
                    l.send(sender, "unknown-boss");
                    return;
                }
                if (plugin.sessions().startEvent(d)) l.send(sender, "admin-event-started", "id", d.id);
                else l.send(sender, "admin-event-failed");
            }
            case "stop" -> {
                BossDefinition d = args.length < 3 ? null : plugin.boss(args[2]);
                if (d == null) {
                    l.send(sender, "unknown-boss");
                    return;
                }
                l.send(sender, "admin-stopped", "n", plugin.sessions().stop(d), "id", d.id);
            }
            case "resetcooldown" -> {
                if (args.length < 3) {
                    l.send(sender, "admin-usage");
                    return;
                }
                OfflinePlayer op = Bukkit.getOfflinePlayerIfCached(args[2]);
                if (op == null) {
                    l.send(sender, "invite-bad-player");
                    return;
                }
                plugin.data().resetPlayer(op.getUniqueId(), args.length >= 4 ? args[3].toLowerCase(Locale.ROOT) : null);
                l.send(sender, "admin-cooldown-reset");
            }
            default -> l.send(sender, "admin-usage");
        }
    }

    // ------------------------------------------------------------------ tab

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            out.addAll(SUBS);
            if (sender.hasPermission("nebulabosses.admin")) out.add("admin");
        } else if (args.length == 2 && args[0].equalsIgnoreCase("join")) {
            plugin.bosses().forEach(d -> out.add(d.id));
        } else if (args.length == 2 && args[0].equalsIgnoreCase("invite")) {
            Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
        } else if (args[0].equalsIgnoreCase("admin") && sender.hasPermission("nebulabosses.admin")) {
            if (args.length == 2) {
                out.addAll(ADMIN);
            } else if (args.length == 3) {
                String a = args[1].toLowerCase(Locale.ROOT);
                if (a.equals("create")) out.add("<id>");
                else if (a.equals("resetcooldown")) Bukkit.getOnlinePlayers().forEach(p -> out.add(p.getName()));
                else plugin.bosses().forEach(d -> out.add(d.id));
            } else if (args.length == 4 && args[1].equalsIgnoreCase("create")) {
                out.addAll(List.of("INSTANCE", "FIXED"));
            } else if (args.length == 4 && args[1].equalsIgnoreCase("resetcooldown")) {
                plugin.bosses().forEach(d -> out.add(d.id));
            }
        }
        String last = args[args.length - 1].toLowerCase(Locale.ROOT);
        return out.stream().filter(s -> s.toLowerCase(Locale.ROOT).startsWith(last)).collect(Collectors.toList());
    }
}

package nebula.bosses;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Registro de todas las salas/peleas activas y reglas para entrar a ellas. */
public final class SessionManager {
    private final NebulaBosses plugin;
    private final List<Session> sessions = new ArrayList<>();
    private final Map<UUID, Session> byPlayer = new HashMap<>();
    private final Map<UUID, Session> byBoss = new HashMap<>();
    private final Map<UUID, Session> invites = new HashMap<>();
    private final Map<UUID, BossDefinition> exitOnRespawn = new HashMap<>();
    private int counter = 0;

    public SessionManager(NebulaBosses plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------------ consultas

    public Session sessionOf(UUID player) {
        return byPlayer.get(player);
    }

    public Session sessionOfBoss(UUID entity) {
        return byBoss.get(entity);
    }

    public void register(UUID player, Session s) {
        byPlayer.put(player, s);
    }

    public void unregister(UUID player) {
        byPlayer.remove(player);
    }

    public void registerBoss(UUID entity, Session s) {
        byBoss.put(entity, s);
    }

    public void unregisterBoss(UUID entity) {
        byBoss.remove(entity);
    }

    public void remove(Session s) {
        sessions.remove(s);
        invites.values().removeIf(x -> x == s);
    }

    /** Primera sesión (de cualquier estado) de ese boss; para arenas FIXED es "la arena". */
    public Session activeFor(BossDefinition d) {
        for (Session s : sessions) if (s.def.id.equals(d.id)) return s;
        return null;
    }

    public int countFor(BossDefinition d) {
        int n = 0;
        for (Session s : sessions) if (s.def.id.equals(d.id)) n++;
        return n;
    }

    private int instanceCount() {
        int n = 0;
        for (Session s : sessions) if (s.def.type == BossDefinition.Type.INSTANCE) n++;
        return n;
    }

    // ------------------------------------------------------------------ entrar

    private boolean precheck(Player p, BossDefinition d) {
        Lang l = plugin.lang();
        if (byPlayer.containsKey(p.getUniqueId())) {
            l.send(p, "already-in");
            return false;
        }
        if (!d.isReady()) {
            l.send(p, "not-configured");
            return false;
        }
        long cd = plugin.data().remaining("player:" + p.getUniqueId() + ":" + d.id);
        if (cd > 0 && !p.hasPermission("nebulabosses.bypass")) {
            l.send(p, "player-cooldown", "time", Lang.time(cd));
            return false;
        }
        return true;
    }

    private Session findOpen(BossDefinition d, UUID who) {
        Session best = null;
        for (Session s : sessions) {
            if (!s.def.id.equals(d.id)) continue;
            if (s.state != Session.State.WAITING && s.state != Session.State.COUNTDOWN) continue;
            if (s.players.size() >= s.maxPlayers()) continue;
            if (s.kind == Session.Kind.MANUAL && s.locked && invites.get(who) != s) continue;
            if (s.kind == Session.Kind.EVENT) return s;
            if (best == null) best = s;
        }
        return best;
    }

    /** /boss join <id> */
    public void join(Player p, BossDefinition d) {
        Lang l = plugin.lang();
        if (!precheck(p, d)) return;
        Session s = findOpen(d, p.getUniqueId());
        if (s == null) {
            if (!d.manual) {
                l.send(p, "manual-disabled", "times", String.join(", ", d.times));
                return;
            }
            if (d.type == BossDefinition.Type.FIXED) {
                if (activeFor(d) != null) {
                    l.send(p, "arena-busy");
                    return;
                }
                long cd = plugin.data().remaining("arena:" + d.id);
                if (cd > 0 && !p.hasPermission("nebulabosses.bypass")) {
                    l.send(p, "arena-cooldown", "time", Lang.time(cd));
                    return;
                }
            } else if (instanceCount() >= plugin.getConfig().getInt("max-concurrent-instances", 3)) {
                l.send(p, "too-many");
                return;
            }
            s = new Session(plugin, d, Session.Kind.MANUAL, ++counter);
            sessions.add(s);
            s.start();
        }
        s.join(p);
    }

    public void invite(Session s, Player from, Player to) {
        invites.put(to.getUniqueId(), s);
        plugin.lang().send(from, "invite-sent", "player", to.getName());
        Component c = plugin.lang().compP("invite-received", "player", from.getName(), "boss", s.def.display)
                .clickEvent(ClickEvent.runCommand("/boss accept"));
        to.sendMessage(c);
    }

    public void accept(Player p) {
        Session s = invites.remove(p.getUniqueId());
        if (s == null || (s.state != Session.State.WAITING && s.state != Session.State.COUNTDOWN)
                || s.players.size() >= s.maxPlayers()) {
            plugin.lang().send(p, "invite-invalid");
            return;
        }
        if (!precheck(p, s.def)) return;
        s.join(p);
    }

    // ------------------------------------------------------------------ eventos programados

    public void announceUpcoming(BossDefinition d, int minutes) {
        Bukkit.broadcast(plugin.lang().compP("event-upcoming", "boss", d.display, "minutes", minutes, "id", d.id));
    }

    /** Abre el evento programado. Devuelve false si no se pudo. */
    public boolean startEvent(BossDefinition d) {
        if (!d.isReady()) {
            plugin.getLogger().warning("Evento de '" + d.id + "' omitido: el boss no está configurado.");
            return false;
        }
        Session existing = activeFor(d);
        if (d.type == BossDefinition.Type.FIXED && existing != null) {
            boolean open = existing.kind == Session.Kind.MANUAL
                    && (existing.state == Session.State.WAITING || existing.state == Session.State.COUNTDOWN);
            if (!open) {
                plugin.getLogger().info("Evento de '" + d.id + "' omitido: la arena está ocupada.");
                Bukkit.broadcast(plugin.lang().compP("event-skipped", "boss", d.display));
                return false;
            }
            existing.convertToEvent();
        } else {
            Session s = new Session(plugin, d, Session.Kind.EVENT, ++counter);
            sessions.add(s);
            s.start();
        }
        Component c = plugin.lang().compP("event-open", "boss", d.display, "s", d.joinWindow, "id", d.id)
                .clickEvent(ClickEvent.runCommand("/boss join " + d.id));
        Bukkit.broadcast(c);
        return true;
    }

    // ------------------------------------------------------------------ salidas y respawn

    public Location exitOf(BossDefinition d) {
        Location l = d.exit == null ? null : d.exit.resolve();
        return l != null ? l : Bukkit.getWorlds().get(0).getSpawnLocation();
    }

    public void sendOut(Player p, BossDefinition d) {
        p.teleport(exitOf(d));
    }

    public void markExit(UUID player, BossDefinition d) {
        exitOnRespawn.put(player, d);
    }

    /** Devuelve el boss del que fue eliminado (y lo borra), o null. */
    public BossDefinition consumeExit(UUID player) {
        return exitOnRespawn.remove(player);
    }

    // ------------------------------------------------------------------ admin

    public int stop(BossDefinition d) {
        int n = 0;
        for (Session s : new ArrayList<>(sessions)) {
            if (s.def.id.equals(d.id)) {
                s.forceStop();
                n++;
            }
        }
        return n;
    }

    public void stopAll() {
        for (Session s : new ArrayList<>(sessions)) s.forceStop();
    }
}

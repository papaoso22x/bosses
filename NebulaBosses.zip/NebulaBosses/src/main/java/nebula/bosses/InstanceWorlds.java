package nebula.bosses;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.stream.Stream;

/** Copia, carga y borra los mundos de las instancias. Solo toca carpetas que empiecen por "bossinst_". */
public final class InstanceWorlds {
    public static final String PREFIX = "bossinst_";

    private final NebulaBosses plugin;

    public InstanceWorlds(NebulaBosses plugin) {
        this.plugin = plugin;
    }

    /** Borra carpetas de instancias que quedaron de un apagado/crash anterior. */
    public void cleanupOrphans() {
        File[] dirs = Bukkit.getWorldContainer().listFiles((d, n) -> n.startsWith(PREFIX));
        if (dirs == null || dirs.length == 0) return;
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            for (File f : dirs) deleteDir(f);
        });
    }

    /** Copia la plantilla (async) y carga el mundo (main thread). Llama a ok o fail en el hilo principal. */
    public void create(String template, String name, Consumer<World> ok, Runnable fail) {
        File src = new File(Bukkit.getWorldContainer(), template);
        if (template.isBlank() || !src.isDirectory()) {
            plugin.getLogger().warning("No existe el mundo plantilla '" + template + "' en la carpeta del servidor.");
            fail.run();
            return;
        }
        World loaded = Bukkit.getWorld(template);
        if (loaded != null) loaded.save();
        File dst = new File(Bukkit.getWorldContainer(), name);
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                copy(src.toPath(), dst.toPath());
            } catch (IOException e) {
                plugin.getLogger().log(Level.SEVERE, "Error copiando la plantilla " + template, e);
                Bukkit.getScheduler().runTask(plugin, fail);
                return;
            }
            Bukkit.getScheduler().runTask(plugin, () -> {
                World w = new WorldCreator(name).createWorld();
                if (w == null) {
                    fail.run();
                    return;
                }
                w.setAutoSave(false);
                ok.accept(w);
            });
        });
    }

    private void copy(Path src, Path dst) throws IOException {
        try (Stream<Path> s = Files.walk(src)) {
            for (Path p : (Iterable<Path>) s::iterator) {
                String fn = p.getFileName().toString();
                if (fn.equals("uid.dat") || fn.equals("session.lock")) continue;
                Path t = dst.resolve(src.relativize(p).toString());
                if (Files.isDirectory(p)) {
                    Files.createDirectories(t);
                } else {
                    Files.createDirectories(t.getParent());
                    Files.copy(p, t, StandardCopyOption.REPLACE_EXISTING);
                }
            }
        }
    }

    /** Descarga el mundo y borra su carpeta. Nunca toca mundos que no sean instancias. */
    public void destroy(World w) {
        String name = w.getName();
        if (!name.startsWith(PREFIX)) return;
        for (Player p : new ArrayList<>(w.getPlayers())) {
            p.teleport(Bukkit.getWorlds().get(0).getSpawnLocation());
        }
        if (!plugin.isEnabled()) { // apagando el servidor: sin tareas programadas
            Bukkit.unloadWorld(w, false);
            deleteDir(new File(Bukkit.getWorldContainer(), name));
            return;
        }
        attemptUnload(name, 0);
    }

    private void attemptUnload(String name, int tries) {
        World w = Bukkit.getWorld(name);
        if (w != null && !Bukkit.unloadWorld(w, false)) {
            if (tries < 10) {
                Bukkit.getScheduler().runTaskLater(plugin, () -> attemptUnload(name, tries + 1), 40L);
            } else {
                plugin.getLogger().warning("No se pudo descargar la instancia " + name + "; se borrará al reiniciar.");
            }
            return;
        }
        Bukkit.getScheduler().runTaskAsynchronously(plugin,
                () -> deleteDir(new File(Bukkit.getWorldContainer(), name)));
    }

    private void deleteDir(File dir) {
        if (!dir.getName().startsWith(PREFIX) || !dir.exists()) return;
        try (Stream<Path> s = Files.walk(dir.toPath())) {
            s.sorted(Comparator.reverseOrder()).forEach(p -> {
                try {
                    Files.delete(p);
                } catch (IOException ignored) {
                    // se reintenta en el próximo arranque
                }
            });
        } catch (IOException e) {
            plugin.getLogger().log(Level.WARNING, "No se pudo borrar " + dir.getName(), e);
        }
    }
}
